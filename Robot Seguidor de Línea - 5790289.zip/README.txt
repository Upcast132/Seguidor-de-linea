Robot Seguidor de Línea by cmarinv2005 on Thingiverse: https://www.thingiverse.com/thing:5790289

Summary:
Los robots seguidores de línea son máquinas móviles capaces de detectar y seguir una línea, la cual se encuentra ubicada en el suelo de una superficie. Normalmente, el camino que el robot debe de seguir es marcado por una línea negra sobre una superficie blanca, lo cual permite obtener un enorme contraste entre los dos colores.Este proyecto está completo y muy bien explicado. tanto el montaje, como el diagrama de conexión y la explicación del código en Arduino.